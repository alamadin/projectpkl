<!-- Konfigurasi Pagination -->

<?php 

$jumlahDataPerhalaman = 3;
$dataBerita = mysqli_query($connect, "SELECT * FROM berita");
$jumlahData = mysqli_num_rows($dataBerita);
$jumlahHalaman = ceil($jumlahData / $jumlahDataPerhalaman);

if (isset($_GET['halaman'])) {
  $halamanAktif = $_GET['halaman'];
} else {
  $halamanAktif = 1;
}

$awalData = ( $jumlahDataPerhalaman * $halamanAktif ) - $jumlahDataPerhalaman;

?>

<!-- Blog Post -->
<?php 
	$query = "SELECT * FROM berita WHERE terbit = '1' ORDER BY ID DESC LIMIT $awalData, $jumlahDataPerhalaman";
	$result = mysqli_query($connect, $query);
?>
<?php while ( $row = mysqli_fetch_assoc($result) ) : ?>
<div class="card mb-4" style="margin-top: 32px;">
  <img class="card-img-top" src="<?= $row['gambar']; ?>" alt="Card image cap">
  <div class="card-body">
    <h2 class="card-title"><?= $row['judul']; ?></h2>
    <p class="card-text"><?= substr(strip_tags($row['isi']),0,200); ?>. . . .</p>
    <a href="./?open=detail&id=<?= $row['ID']; ?>" class="btn btn-primary">Baca Selengkapnya &rarr;</a>
  </div>

  	
</div>
<?php endwhile; ?>

