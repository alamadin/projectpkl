 <!-- Footer -->
 <footer class="py-2 bg-dark">
   <div class="container">
     <p class="m-0 text-center text-white"></p>
   </div>
   <!-- /.container -->
 </footer>

 <!-- Bootstrap core JavaScript -->
 <script src="assets/vendor/jquery/jquery.min.js"></script>
 <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

 </body>

 </html>