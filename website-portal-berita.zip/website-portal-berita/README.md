# Website-Portal-Berita-PHP-native-Mysqli-Bootstrap-4
Website Portal Berita menggunakan PHP native (PHP 7), Cocok untuk Tugas Kuliah. Project Website ini Masih Banyak Kurang nya.

Yang harus diperbaiki

-validation belum diterapkan

-pagination pada halaman admin berita belum diterapkan

-pagination pada halaman admin kategori belum diterapkan
